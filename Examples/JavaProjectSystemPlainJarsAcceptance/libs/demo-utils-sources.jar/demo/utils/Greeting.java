package demo.utils;

/** Classe di prova per Java CPS F4.D.2.1. */
public final class Greeting {
    private Greeting() { }

    public static String message() {
        return "JAR esterno caricato correttamente";
    }
}
