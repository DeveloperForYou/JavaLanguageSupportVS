$javaPackageHeader$public @interface $safeitemname$ {
}
