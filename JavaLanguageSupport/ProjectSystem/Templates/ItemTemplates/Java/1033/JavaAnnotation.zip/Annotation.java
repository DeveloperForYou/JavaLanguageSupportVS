public @interface $safeitemname$ {
}
