$javaPackageHeader$public interface $safeitemname$ {

}
