public interface $safeitemname$ {

}
