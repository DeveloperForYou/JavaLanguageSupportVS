public abstract class $safeitemname$ {

}
