$javaPackageHeader$public class $safeitemname$ {

}
