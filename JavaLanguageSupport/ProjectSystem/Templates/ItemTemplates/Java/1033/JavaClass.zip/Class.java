public class $safeitemname$ {

}
